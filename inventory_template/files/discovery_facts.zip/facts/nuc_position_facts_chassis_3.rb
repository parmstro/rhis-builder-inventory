#Assign a position based on the INTEL NUCs onboard Interface MAC Address
#2025-06-19
Facter.add("chassis_position") do
  setcode do
    mac = Facter.value('discovery_bootif')
    case mac
    when "94:c6:91:a3:16:b8"
      "c3s1n1"

    when "94:c6:91:a3:19:29"
      "c3s1n2"

    when "94:c6:91:a3:19:5b"
      "c3s1n3"

    when "b8:ae:ed:7b:8c:e8"
      "c3s1n4"

    when "f4:4d:30:6f:0b:50"
      "c3s1n5"

    when "f4:4d:30:6f:07:59"
      "c3s1n6"

    when "54:b2:03:f1:0b:9f"
      "c3s1n7"

    when "54:b2:03:f1:0b:d2"
      "c3s2n1"

    when "54:b2:03:f1:0b:6a"
      "c3s2n2"

    when "54:b2:03:f1:0b:46"
      "c3s2n3"

    when "54:b2:03:f1:00:6f"
      "c3s2n4"

    when "54:b2:03:f1:0b:e3"
      "c3s2n5"

    when "54:b2:03:f1:00:cd"
      "c3s2n6"

    when "54:b2:03:f1:0b:ef"
      "c3s2n7"
    
    else
      mac
    end
  end
end
