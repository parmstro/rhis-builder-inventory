#Assign a position based on the INTEL NUCs onboard Interface MAC Address
#2025-06-19
Facter.add("chassis_position") do
  setcode do
    mac = Facter.value('discovery_bootif')
    case mac
    when "94:c6:91:a3:1c:ca"
      "c1s1n1"
    
    when "94:c6:91:a3:16:71"
      "c1s1n2"
    
    when "94:c6:91:a3:1d:6a"
      "c1s1n3"
    
    when "94:c6:91:a3:1b:79"
      "c1s1n4"
    
    when "94:c6:91:a3:1d:fb"
      "c1s1n5"
    
    when "94:c6:91:a3:1d:ed"
      "c1s1n6"
    
    when "94:c6:91:a3:1d:50"
      "c1s1n7"
    
    when "94:c6:91:14:23:ac"
      "c1s2n1"
    
    when "94:c6:91:a3:19:41"
      "c1s2n2"
    
    when "94:c6:91:a3:17:1e"
      "c1s2n3"
    
    when "94:c6:91:13:37:9e"
      "c1s2n4"
    
    when "94:c6:91:a3:18:02"
      "c1s2n5"
    
    when "94:c6:91:a3:17:3d"
      "c1s2n6"
    
    when "94:c6:91:a3:1a:7f"
      "c1s2n7"
    
    when "b8:ae:ed:74:0d:40"
      "c2s1n1"
    
    when "f4:4d:30:6f:0a:ff"
      "c2s1n2"
    
    when "f4:4d:30:6f:06:66"
      "c2s1n3"
    
    when "94:c6:91:a2:cb:55"
      "c2s1n4"
    
    when "b8:ae:ed:73:f2:80"
      "c2s1n5"
    
    when "94:c6:91:a3:19:9e"
      "c2s1n6"
    
    when "b8:ae:ed:7d:d6:5f"
      "c2s1n7"
    
    when "94:c6:91:a3:16:75"
      "c2s2n1"
    
    when "f4:4d:30:6f:0a:cb"
      "c2s2n2"
    
    when "94:c6:91:13:3d:db"
      "c2s2n3"
    
    when "94:c6:91:a2:cb:39"
      "c2s2n4"
    
    when "94:c6:91:a2:cd:d4"
      "c2s2n5"
    
    when "94:c6:91:a2:6e:f6"
      "c2s2n6"
    
    when "94:c6:91:a2:76:74"
      "c2s2n7"
    
    else
      mac
    end
  end
end
