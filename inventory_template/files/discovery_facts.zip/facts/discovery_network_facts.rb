# discovery_network_facts.rb
# Custom Facter facts for the Foreman Discovery image.
# Exposes network configuration of the interface used for discovery
# so that Kexec templates can perform a proper network-attached kernel switch
# when booting via PXE from Satellite (where fdi.* kernel args are absent).
#
# Facts provided:
#   discovery_ip_cidr   - IP address with prefix length (e.g. 192.168.1.10/24)
#   discovery_ip        - IP address in dot notation
#   discovery_netmask   - Subnet mask in dot notation (e.g. 255.255.255.0)
#   discovery_gateway   - Default gateway in dot notation
#   discovery_dns       - First nameserver from /etc/resolv.conf
#   append              - acpi_rsdp=<address> from /sys/firmware/efi/systab (for kexec on UEFI systems)

module DiscoveryNetworkFacts
  def self.iface
    bootif_mac = Facter.value('discovery_bootif')
    return nil unless bootif_mac
    Dir.glob('/sys/class/net/*').each do |path|
      addr_file = "#{path}/address"
      next unless File.exist?(addr_file)
      return File.basename(path) if File.read(addr_file).strip.casecmp(bootif_mac).zero?
    end
    nil
  end

  def self.inet_match(iface)
    return nil unless iface
    out = Facter::Core::Execution.execute("ip -4 addr show #{iface} 2>/dev/null")
    out.match(/inet\s+(\d+\.\d+\.\d+\.\d+)\/(\d+)/)
  end

  def self.prefix_to_netmask(prefix_len)
    bits = prefix_len.to_i
    mask = (0xFFFFFFFF << (32 - bits)) & 0xFFFFFFFF
    [24, 16, 8, 0].map { |s| (mask >> s) & 0xFF }.join('.')
  end

  def self.gateway(iface)
    return nil unless iface
    routes = Facter::Core::Execution.execute("ip -4 route show 2>/dev/null")
    # Prefer a default route tied to the discovery interface
    m = routes.match(/default\s+via\s+(\d+\.\d+\.\d+\.\d+)\s+dev\s+#{Regexp.escape(iface)}/)
    m ||= routes.match(/default\s+via\s+(\d+\.\d+\.\d+\.\d+)/)
    m ? m[1] : nil
  end

  def self.dns
    return nil unless File.exist?('/etc/resolv.conf')
    File.readlines('/etc/resolv.conf').each do |line|
      m = line.match(/^nameserver\s+(\S+)/)
      return m[1] if m
    end
    nil
  end
end

Facter.add('discovery_ip_cidr') do
  setcode do
    iface = DiscoveryNetworkFacts.iface
    m = DiscoveryNetworkFacts.inet_match(iface)
    m ? "#{m[1]}/#{m[2]}" : nil
  end
end

Facter.add('discovery_ip') do
  setcode do
    iface = DiscoveryNetworkFacts.iface
    m = DiscoveryNetworkFacts.inet_match(iface)
    m ? m[1] : nil
  end
end

Facter.add('discovery_netmask') do
  setcode do
    iface = DiscoveryNetworkFacts.iface
    m = DiscoveryNetworkFacts.inet_match(iface)
    m ? DiscoveryNetworkFacts.prefix_to_netmask(m[2]) : nil
  end
end

Facter.add('discovery_gateway') do
  setcode do
    DiscoveryNetworkFacts.gateway(DiscoveryNetworkFacts.iface)
  end
end

Facter.add('discovery_dns') do
  setcode do
    DiscoveryNetworkFacts.dns
  end
end

Facter.add('append') do
  setcode do
    systab = '/sys/firmware/efi/systab'
    next nil unless File.exist?(systab)
    line = File.readlines(systab).find { |l| l.start_with?('ACPI') }
    next nil unless line
    value = line.chomp.split('=', 2).last
    value && !value.empty? ? "acpi_rsdp=#{value}" : nil
  end
end
